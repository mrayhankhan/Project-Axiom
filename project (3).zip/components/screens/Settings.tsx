import React, { useState } from 'react';
import { Card } from '../Card';
import { Button } from '../Button';
import { Input } from '../Input';
import { Select } from '../Select';
import { Badge } from '../Badge';
import { Key, Webhook, Database, Copy, Plus, Trash2 } from 'lucide-react';

export function Settings() {
  const [activeTab, setActiveTab] = useState<'workspace' | 'api' | 'integrations' | 'audit'>('workspace');
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-neutral-900">Settings</h2>
        <p className="text-sm text-neutral-500 mt-1">Manage workspace configuration and integrations</p>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-neutral-200">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('workspace')}
            className={`pb-3 px-1 border-b-2 transition-colors ${
              activeTab === 'workspace'
                ? 'border-primary-700 text-primary-700'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Workspace
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`pb-3 px-1 border-b-2 transition-colors ${
              activeTab === 'api'
                ? 'border-primary-700 text-primary-700'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            API Keys
          </button>
          <button
            onClick={() => setActiveTab('integrations')}
            className={`pb-3 px-1 border-b-2 transition-colors ${
              activeTab === 'integrations'
                ? 'border-primary-700 text-primary-700'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Integrations
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`pb-3 px-1 border-b-2 transition-colors ${
              activeTab === 'audit'
                ? 'border-primary-700 text-primary-700'
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Audit Logs
          </button>
        </div>
      </div>
      
      {/* Workspace Settings */}
      {activeTab === 'workspace' && (
        <div className="space-y-6">
          <Card>
            <h3 className="font-semibold text-neutral-900 mb-4">Workspace Information</h3>
            <div className="space-y-4">
              <Input label="Workspace Name" defaultValue="Axiom Enterprise" />
              <Select
                label="Timezone"
                options={[
                  { value: 'UTC', label: 'UTC' },
                  { value: 'America/New_York', label: 'Eastern Time (ET)' },
                  { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
                  { value: 'Europe/London', label: 'London (GMT)' }
                ]}
                defaultValue="America/New_York"
              />
              <Select
                label="Default Language"
                options={[
                  { value: 'en', label: 'English' },
                  { value: 'es', label: 'Spanish' },
                  { value: 'fr', label: 'French' },
                  { value: 'de', label: 'German' }
                ]}
                defaultValue="en"
              />
              <div className="pt-4">
                <Button variant="primary">Save Changes</Button>
              </div>
            </div>
          </Card>
          
          <Card>
            <h3 className="font-semibold text-neutral-900 mb-4">Data Retention Policy</h3>
            <div className="space-y-4">
              <Select
                label="Document Retention"
                options={[
                  { value: '30', label: '30 days' },
                  { value: '90', label: '90 days' },
                  { value: '180', label: '180 days' },
                  { value: '365', label: '1 year' },
                  { value: '-1', label: 'Indefinite' }
                ]}
                defaultValue="365"
                helperText="How long to retain uploaded documents"
              />
              <Select
                label="Audit Log Retention"
                options={[
                  { value: '90', label: '90 days' },
                  { value: '180', label: '180 days' },
                  { value: '365', label: '1 year' },
                  { value: '730', label: '2 years' }
                ]}
                defaultValue="365"
                helperText="How long to retain audit trail records"
              />
              <div className="pt-4">
                <Button variant="primary">Update Policy</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
      
      {/* API Keys */}
      {activeTab === 'api' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-neutral-600">Manage API keys for programmatic access</p>
            <Button variant="primary" icon={<Plus className="w-4 h-4" />}>
              Create API Key
            </Button>
          </div>
          
          <div className="space-y-3">
            <APIKeyCard
              name="Production API Key"
              key_preview="ax_prod_••••••••••••4f2a"
              created="2024-01-10"
              lastUsed="2 hours ago"
              usage="2.4M requests"
            />
            <APIKeyCard
              name="Development API Key"
              key_preview="ax_dev_••••••••••••8b3c"
              created="2024-01-05"
              lastUsed="1 day ago"
              usage="842K requests"
            />
            <APIKeyCard
              name="Testing API Key"
              key_preview="ax_test_••••••••••••1a9d"
              created="2024-01-01"
              lastUsed="Never"
              usage="0 requests"
            />
          </div>
        </div>
      )}
      
      {/* Integrations */}
      {activeTab === 'integrations' && (
        <div className="space-y-6">
          <p className="text-sm text-neutral-600">Connect external data sources and services</p>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <IntegrationCard
              name="Amazon S3"
              description="Import documents from S3 buckets"
              icon={<Database className="w-6 h-6" />}
              connected={true}
              bucket="axiom-docs-prod"
            />
            <IntegrationCard
              name="SharePoint"
              description="Sync documents from SharePoint"
              icon={<Database className="w-6 h-6" />}
              connected={true}
              bucket="company.sharepoint.com"
            />
            <IntegrationCard
              name="Google Drive"
              description="Import documents from Google Drive"
              icon={<Database className="w-6 h-6" />}
              connected={false}
            />
            <IntegrationCard
              name="Box"
              description="Sync documents from Box"
              icon={<Database className="w-6 h-6" />}
              connected={false}
            />
          </div>
          
          <Card>
            <h3 className="font-semibold text-neutral-900 mb-4">Webhooks</h3>
            <div className="space-y-3">
              <WebhookItem
                url="https://api.company.com/webhooks/axiom"
                events={['evaluation.completed', 'document.indexed', 'risk.alert']}
                status="active"
              />
              <Button variant="secondary" size="sm" icon={<Plus className="w-4 h-4" />}>
                Add Webhook
              </Button>
            </div>
          </Card>
        </div>
      )}
      
      {/* Audit Logs */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <Input placeholder="Search audit logs..." className="flex-1" />
            <Select
              options={[
                { value: 'all', label: 'All Actions' },
                { value: 'document', label: 'Document Actions' },
                { value: 'user', label: 'User Actions' },
                { value: 'settings', label: 'Settings Changes' }
              ]}
              placeholder="Filter by action"
              className="w-48"
            />
          </div>
          
          <Card padding="none">
            <div className="divide-y divide-neutral-200">
              <AuditLogItem
                action="Document uploaded"
                user="Sarah Chen"
                details="Credit Risk Model Documentation v2.3.pdf"
                timestamp="2024-01-15 10:23:45"
              />
              <AuditLogItem
                action="Evaluation started"
                user="John Doe"
                details="Evaluation #342 for Claims Processor v2"
                timestamp="2024-01-15 09:15:22"
              />
              <AuditLogItem
                action="API key created"
                user="Admin"
                details="Production API Key"
                timestamp="2024-01-14 14:32:11"
              />
              <AuditLogItem
                action="User invited"
                user="John Doe"
                details="alice.johnson@company.com as Analyst"
                timestamp="2024-01-14 11:08:33"
              />
              <AuditLogItem
                action="Risk alert created"
                user="System"
                details="Model drift detected in Claims Processor v2"
                timestamp="2024-01-13 16:42:18"
              />
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

function APIKeyCard({ name, key_preview, created, lastUsed, usage }: {
  name: string;
  key_preview: string;
  created: string;
  lastUsed: string;
  usage: string;
}) {
  return (
    <Card>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Key className="w-4 h-4 text-neutral-500" />
            <h4 className="font-medium text-neutral-900">{name}</h4>
          </div>
          <div className="flex items-center gap-4 text-sm text-neutral-600 mb-3">
            <code className="px-2 py-1 bg-neutral-100 rounded font-mono text-xs">{key_preview}</code>
            <button className="text-primary-700 hover:text-primary-900" title="Copy full key">
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex items-center gap-4 text-xs text-neutral-500">
            <span>Created {created}</span>
            <span>•</span>
            <span>Last used {lastUsed}</span>
            <span>•</span>
            <span>{usage}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="tertiary" size="sm">Configure</Button>
          <Button variant="danger" size="sm" icon={<Trash2 className="w-4 h-4" />}>
            Revoke
          </Button>
        </div>
      </div>
    </Card>
  );
}

function IntegrationCard({ name, description, icon, connected, bucket }: {
  name: string;
  description: string;
  icon: React.ReactNode;
  connected: boolean;
  bucket?: string;
}) {
  return (
    <Card>
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center text-primary-700 flex-shrink-0">
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-medium text-neutral-900">{name}</h4>
            {connected && <Badge variant="success" size="sm" dot>Connected</Badge>}
          </div>
          <p className="text-sm text-neutral-600 mb-2">{description}</p>
          {bucket && (
            <p className="text-xs text-neutral-500 font-mono">{bucket}</p>
          )}
          <div className="mt-3">
            {connected ? (
              <div className="flex items-center gap-2">
                <Button variant="secondary" size="sm">Configure</Button>
                <Button variant="tertiary" size="sm">Disconnect</Button>
              </div>
            ) : (
              <Button variant="primary" size="sm">Connect</Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

function WebhookItem({ url, events, status }: {
  url: string;
  events: string[];
  status: 'active' | 'inactive';
}) {
  return (
    <div className="flex items-start justify-between p-4 border border-neutral-200 rounded-lg">
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-2">
          <Webhook className="w-4 h-4 text-neutral-500" />
          <code className="text-sm text-neutral-900 font-mono">{url}</code>
          <Badge variant={status === 'active' ? 'success' : 'neutral'} size="sm" dot>
            {status}
          </Badge>
        </div>
        <div className="flex flex-wrap gap-1">
          {events.map((event) => (
            <Badge key={event} variant="neutral" size="sm">{event}</Badge>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-2 ml-4">
        <Button variant="tertiary" size="sm">Test</Button>
        <Button variant="tertiary" size="sm">Edit</Button>
      </div>
    </div>
  );
}

function AuditLogItem({ action, user, details, timestamp }: {
  action: string;
  user: string;
  details: string;
  timestamp: string;
}) {
  return (
    <div className="p-4 hover:bg-neutral-50 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-neutral-900">{action}</span>
            <Badge variant="neutral" size="sm">{user}</Badge>
          </div>
          <p className="text-sm text-neutral-600">{details}</p>
        </div>
        <span className="text-xs text-neutral-500 whitespace-nowrap ml-4">{timestamp}</span>
      </div>
    </div>
  );
}
